
import ex02_teste01_poo1.Menu;

/**Docente: Maculuve, Cristiano
 * Discente: Semo, Agneila Karina Celestino
 * @author Semo, Agneila Karina Celestino
 */



public class Ex02_teste01_POO1 {

 
    public static void main(String[] args) {
    Menu m = new Menu();
    }
    
}
